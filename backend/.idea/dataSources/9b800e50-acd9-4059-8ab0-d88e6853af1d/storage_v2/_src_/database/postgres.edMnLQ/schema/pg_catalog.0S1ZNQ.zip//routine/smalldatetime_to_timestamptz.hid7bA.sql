create function smalldatetime_to_timestamptz(smalldatetime) returns timestamp with time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.timestamptz_in(pg_catalog.smalldatetime_out($1), 0::Oid, -1)
$$;

alter function smalldatetime_to_timestamptz(smalldatetime) owner to omm;

