create function bpchar_to_smalldatetime(character) returns smalldatetime
    immutable
    strict
    language sql
as
$$
select pg_catalog.smalldatetime_in(pg_catalog.bpcharout($1), 0::Oid, -1)
$$;

alter function bpchar_to_smalldatetime(char) owner to omm;

