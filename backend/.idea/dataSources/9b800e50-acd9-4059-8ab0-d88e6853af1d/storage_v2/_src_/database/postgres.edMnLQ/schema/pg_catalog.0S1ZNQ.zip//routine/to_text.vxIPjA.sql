create function to_text(double precision) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.float8out($1) AS VARCHAR)
$$;

alter function to_text(double precision) owner to omm;

