create function to_nvarchar2(interval) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.interval_out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(interval) owner to omm;

