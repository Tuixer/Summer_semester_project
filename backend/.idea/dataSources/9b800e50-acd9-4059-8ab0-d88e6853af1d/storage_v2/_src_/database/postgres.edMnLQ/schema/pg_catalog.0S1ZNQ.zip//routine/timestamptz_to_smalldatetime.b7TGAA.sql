create function timestamptz_to_smalldatetime(timestamp with time zone) returns smalldatetime
    immutable
    strict
    language sql
as
$$
select pg_catalog.smalldatetime_in(pg_catalog.TIMESTAMPTZ_OUT($1), 0::Oid, -1)
$$;

alter function timestamptz_to_smalldatetime(timestamp with time zone) owner to omm;

