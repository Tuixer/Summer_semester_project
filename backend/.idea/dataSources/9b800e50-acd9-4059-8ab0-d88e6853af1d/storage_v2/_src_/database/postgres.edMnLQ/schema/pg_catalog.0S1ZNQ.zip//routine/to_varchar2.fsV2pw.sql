create function to_varchar2(timestamp without time zone) returns character varying
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.timestamp_out($1) AS VARCHAR2)
$$;

alter function to_varchar2(timestamp) owner to omm;

