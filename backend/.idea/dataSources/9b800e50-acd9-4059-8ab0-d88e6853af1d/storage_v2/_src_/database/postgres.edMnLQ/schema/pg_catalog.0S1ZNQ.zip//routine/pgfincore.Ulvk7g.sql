create function pgfincore(relname regclass, getdatabit boolean, OUT relpath text, OUT segment integer, OUT os_page_size bigint, OUT rel_os_pages bigint, OUT pages_mem bigint, OUT group_mem bigint, OUT os_pages_free bigint, OUT databit bit varying, OUT pages_dirty bigint, OUT group_dirty bigint) returns SETOF record
    cost 1
    rows 1
    language sql
as
$$
SELECT * from pg_catalog.pgfincore($1, 'main', $2)
$$;

comment on function pgfincore(regclass, boolean, out text, out integer, out bigint, out bigint, out bigint, out bigint, out bigint, out bit varying, out bigint, out bigint) is 'less than';

alter function pgfincore(regclass, boolean, out text, out integer, out bigint, out bigint, out bigint, out bigint, out bigint, out bit varying, out bigint, out bigint) owner to omm;

