create function to_text(timestamp with time zone) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.timestamptz_out($1) AS VARCHAR2)
$$;

alter function to_text(timestamp with time zone) owner to omm;

