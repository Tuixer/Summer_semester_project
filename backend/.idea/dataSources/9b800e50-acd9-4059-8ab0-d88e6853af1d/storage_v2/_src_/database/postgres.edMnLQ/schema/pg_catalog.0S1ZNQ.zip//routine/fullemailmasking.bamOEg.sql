create function fullemailmasking(col text, letter character DEFAULT 'x'::bpchar) returns text
    language plpgsql
as
$$
declare 
    pos INTEGER := position('@' in col);
    dot_pos INTEGER := pg_catalog.length(col) - position('.' in pg_catalog.reverse(col)) + 1;
begin
    return CASE WHEN pos > 2 and dot_pos > pos THEN
    pg_catalog.repeat(letter, pos - 1) || '@' || pg_catalog.repeat(letter,  dot_pos - pos - 1) || pg_catalog.substring(col, dot_pos, pg_catalog.length(col) - dot_pos +1)
    ELSE
        col
    end;
end;
$$;

alter function fullemailmasking(text, char) owner to omm;

