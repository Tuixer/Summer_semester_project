create function to_char(double precision) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.float8out($1) AS VARCHAR2)
$$;

alter function to_char(double precision) owner to omm;

