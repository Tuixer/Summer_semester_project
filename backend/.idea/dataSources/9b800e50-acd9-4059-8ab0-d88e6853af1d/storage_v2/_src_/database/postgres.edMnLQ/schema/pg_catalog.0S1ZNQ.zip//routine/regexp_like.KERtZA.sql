create function regexp_like(text, text) returns boolean
    immutable
    strict
    language sql
as
$$
select $1 ~ $2
$$;

alter function regexp_like(text, text) owner to omm;

