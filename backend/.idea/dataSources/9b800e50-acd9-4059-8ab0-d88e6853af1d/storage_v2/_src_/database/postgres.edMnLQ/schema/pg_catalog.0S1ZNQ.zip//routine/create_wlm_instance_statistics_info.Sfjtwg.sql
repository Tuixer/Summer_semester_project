create function create_wlm_instance_statistics_info() returns integer
    language plpgsql
as
$$
DECLARE
	query_str text;
	record_cnt int;
	BEGIN
	    record_cnt := 0;
		query_str := 'SELECT * FROM pg_catalog.pg_stat_get_wlm_instance_info_with_cleanup()';
        EXECUTE 'INSERT INTO gs_wlm_instance_history ' || query_str;
        return record_cnt;
	END;
$$;

alter function create_wlm_instance_statistics_info() owner to omm;

