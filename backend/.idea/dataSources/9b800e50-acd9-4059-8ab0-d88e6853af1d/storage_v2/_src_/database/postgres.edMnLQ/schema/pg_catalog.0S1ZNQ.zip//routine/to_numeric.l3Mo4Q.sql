create function to_numeric(double precision) returns numeric
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.TO_NUMBER($1::TEXT)
$$;

alter function to_numeric(double precision) owner to omm;

