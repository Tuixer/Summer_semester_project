create function substr(text, bigint, bigint) returns text
    immutable
    strict
    language sql
as
$$
select pg_catalog.SUBSTR($1, $2::INT4, $3::INT4);
$$;

alter function substr(text, bigint, bigint) owner to omm;

