create function gs_wlm_persistent_user_resource_info() returns SETOF record
    language plpgsql
as
$$
DECLARE
        query_str text;
        insert_str text;
        row_data record;
        BEGIN
            query_str := 'SELECT * FROM pg_total_user_resource_info';
        FOR row_data IN EXECUTE(query_str) LOOP
            insert_str := 'INSERT INTO gs_wlm_user_resource_history values (''' || row_data.username || ''', CURRENT_TIMESTAMP, ' || row_data.used_memory || ', ' || row_data.total_memory || ', ' ||
             row_data.used_cpu || ', ' || row_data.total_cpu || ',' ||  row_data.used_space || ',' || row_data.total_space || ',' || row_data.used_temp_space || ',' || row_data.total_temp_space || ',' ||
             row_data.used_spill_space || ',' || row_data.total_spill_space || ',' || row_data.read_kbytes || ',' || row_data.write_kbytes || ',' || row_data.read_counts || ',' || row_data.write_counts || ',' ||
             row_data.read_speed || ',' || row_data.write_speed || ')';

            EXECUTE(insert_str);
        END LOOP;
        return;
        END;
$$;

alter function gs_wlm_persistent_user_resource_info() owner to omm;

