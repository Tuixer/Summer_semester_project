create function pgxc_log_comm_status() returns void
    language plpgsql
as
$$
DECLARE
	row_name record;
	query_str text;
	query_str_nodes text;
	BEGIN
		--Get all the node names
		query_str_nodes := 'SELECT node_name FROM pgxc_node WHERE nodeis_active = true';
		FOR row_name IN EXECUTE(query_str_nodes) LOOP
			query_str := 'EXECUTE DIRECT ON (' || row_name.node_name || ') ''SELECT pg_log_comm_status()''';
			EXECUTE(query_str);
		END LOOP;
		return;
	END;
$$;

alter function pgxc_log_comm_status() owner to omm;

