create function gather_encoding_info(datname text) returns integer
    language plpgsql
as
$$
DECLARE
    BEGIN
        EXECUTE 'INSERT INTO gs_wlm_plan_encoding_table
                    (queryid, plan_node_id, parent_node_id, encode, startup_time, total_time, rows, peak_memory)
                 SELECT queryid, plan_node_id, parent_node_id, encode, startup_time, total_time, rows, peak_memory
                 FROM pg_catalog.encode_feature_perf_hist('''|| datname ||''') order by queryid, plan_node_id;';
        RETURN 0;
    END;
$$;

alter function gather_encoding_info(text) owner to omm;

