create function timetz_text(time with time zone) returns text
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.timetz_out($1) AS text)
$$;

alter function timetz_text(time with time zone) owner to omm;

