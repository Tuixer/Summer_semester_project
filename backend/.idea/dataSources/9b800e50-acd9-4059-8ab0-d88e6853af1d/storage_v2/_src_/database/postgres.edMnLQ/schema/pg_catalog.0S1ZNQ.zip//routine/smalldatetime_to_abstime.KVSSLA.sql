create function smalldatetime_to_abstime(smalldatetime) returns abstime
    immutable
    strict
    language sql
as
$$
select pg_catalog.abstimein(pg_catalog.smalldatetime_out($1))
$$;

alter function smalldatetime_to_abstime(smalldatetime) owner to omm;

