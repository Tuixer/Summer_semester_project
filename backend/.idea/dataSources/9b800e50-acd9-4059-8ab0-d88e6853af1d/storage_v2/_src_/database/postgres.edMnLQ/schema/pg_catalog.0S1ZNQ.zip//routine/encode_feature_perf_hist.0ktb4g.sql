create function encode_feature_perf_hist(datname text, OUT queryid bigint, OUT plan_node_id integer, OUT parent_node_id integer, OUT left_child_id integer, OUT right_child_id integer, OUT encode text, OUT startup_time bigint, OUT total_time bigint, OUT rows bigint, OUT peak_memory integer) returns SETOF record
    language plpgsql
as
$$
DECLARE
    query_str_delete text;
    query_str_select text;
    query_str_encode text;
    encoded_record integer;
    row_data record;
    encoded_data record;
    dop integer;
    operation text;
    orientation text;
    strategy text;
    options text;
    condition text;
    projection text;
    BEGIN
        query_str_select := 'SELECT * FROM gs_wlm_plan_operator_info where datname ='''|| datname || ''';';
        FOR row_data IN EXECUTE(query_str_select) LOOP
            queryid = row_data.queryid;
            plan_node_id = row_data.plan_node_id;
            parent_node_id = row_data.parent_node_id;
            left_child_id = row_data.left_child_id;
            right_child_id = row_data.right_child_id;
            startup_time = row_data.startup_time;
            total_time = row_data.total_time;
            rows = row_data.actual_rows;
            peak_memory = row_data.max_peak_memory;
            operation = row_data.operation;
            orientation = row_data.orientation;
            strategy = row_data.strategy;
            options = row_data.options;
            dop = row_data.query_dop;
            condition = row_data.condition;
            projection = row_data.projection;
            query_str_encode := 'SELECT pg_catalog.encode_plan_node($tag$'|| operation ||'$tag$,$tag$'|| orientation ||'$tag$,$tag$'|| strategy ||'$tag$,$tag$ '|| options || '$tag$,$tag$'|| dop ||'$tag$,$tag$' || condition || '$tag$,$tag$' || projection || '$tag$) as result;';
            EXECUTE query_str_encode INTO encoded_data;
            encode = encoded_data.result;
        return next;
        END LOOP;
    END;
$$;

alter function encode_feature_perf_hist(text, out bigint, out integer, out integer, out integer, out integer, out text, out bigint, out bigint, out bigint, out integer) owner to omm;

