create function create_wlm_session_info(flag integer) returns integer
    language plpgsql
as
$$
DECLARE
	query_str text;
	record_cnt int;
	BEGIN
		record_cnt := 0;
		
		query_str := 'SELECT * FROM pg_catalog.pg_stat_get_wlm_session_info(1)';
		
		IF flag > 0 THEN
			EXECUTE 'INSERT INTO gs_wlm_session_query_info_all ' || query_str;
		ELSE
			EXECUTE query_str;
		END IF;
		
		RETURN record_cnt;
	END;
$$;

alter function create_wlm_session_info(integer) owner to omm;

