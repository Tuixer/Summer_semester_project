create function smalldatetime_to_timestamp(smalldatetime) returns timestamp without time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.timestamp_in(pg_catalog.smalldatetime_out($1), 0::Oid, -1)
$$;

alter function smalldatetime_to_timestamp(smalldatetime) owner to omm;

