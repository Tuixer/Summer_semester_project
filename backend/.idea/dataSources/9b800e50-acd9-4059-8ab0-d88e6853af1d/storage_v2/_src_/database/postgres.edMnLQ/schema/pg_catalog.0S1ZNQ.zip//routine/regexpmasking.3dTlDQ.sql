create function regexpmasking(col text, reg text, replace_text text, pos integer DEFAULT 0, reg_len integer DEFAULT (-1)) returns text
    language plpgsql
as
$$
declare
	size INTEGER := pg_catalog.length(col);
	endpos INTEGER;
	startpos INTEGER;
	lstr text;
	rstr text;
	ltarget text;
begin
	startpos := pos;
	IF pos < 0 THEN startpos := 0; END IF;
	IF pos >= size THEN startpos := size; END IF;
	endpos := reg_len + startpos - 1;
	IF reg_len < 0 THEN endpos := size - 1; END IF;
	IF reg_len + startpos >= size THEN endpos := size - 1; END IF;
	lstr := pg_catalog.left(col, startpos);
	rstr := pg_catalog.right(col, size - endpos - 1);
	ltarget := pg_catalog.substring(col, startpos+1, endpos - startpos + 1);
    ltarget := pg_catalog.REGEXP_REPLACE(ltarget, reg, replace_text, 'g');
    return lstr || ltarget || rstr;
end;
$$;

alter function regexpmasking(text, text, text, integer, integer) owner to omm;

