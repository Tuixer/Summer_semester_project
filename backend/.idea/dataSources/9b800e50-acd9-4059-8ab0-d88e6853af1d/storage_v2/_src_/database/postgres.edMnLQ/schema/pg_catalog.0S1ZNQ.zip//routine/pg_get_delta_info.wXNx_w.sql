create function pg_get_delta_info(rel text, schema_name text, OUT part_name text, OUT live_tuple bigint, OUT data_size bigint, OUT blocknum bigint) returns SETOF record
    language plpgsql
as
$$
DECLARE
	query_info_str text;
	query_str text;
	query_part_str text;
	query_select_str text;
	query_size_str text;
	row_info_data record;
	row_data record;
	row_part_info record;
	BEGIN
		query_info_str := 'SELECT C.oid,C.reldeltarelid,C.parttype FROM pg_class C LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)  WHERE C.relname = '''|| rel ||''' and N.nspname = '''|| schema_name ||'''';
		FOR row_info_data IN EXECUTE(query_info_str) LOOP
		IF row_info_data.parttype = 'n' THEN
			query_str := 'SELECT relname,oid from pg_class where oid= '||row_info_data.reldeltarelid||'';
			EXECUTE(query_str) INTO row_data;
			query_select_str := 'select pg_catalog.count(*) from cstore.' || row_data.relname || '';
			EXECUTE (query_select_str) INTO live_tuple;
			query_size_str := 'select * from pg_catalog.pg_relation_size(' || row_data.oid || ')';
			EXECUTE (query_size_str) INTO data_size;
			blockNum := data_size/8192;
			part_name := 'non partition table';
			return next;
		ELSE
			query_part_str := 'SELECT relname,reldeltarelid from pg_partition where parentid = '||row_info_data.oid|| 'and relname <> '''||rel||'''';
			FOR row_part_info IN EXECUTE(query_part_str) LOOP
				query_str := 'SELECT relname,oid from pg_class where  oid = '||row_part_info.reldeltarelid||'';
				part_name := row_part_info.relname;
				FOR row_data IN EXECUTE(query_str) LOOP
					query_select_str := 'select pg_catalog.count(*) from cstore.' || row_data.relname || '';
					EXECUTE (query_select_str) INTO live_tuple;
					query_size_str := 'select * from pg_catalog.pg_relation_size(' || row_data.oid || ')';
					EXECUTE (query_size_str) INTO data_size;
				END LOOP;
				blockNum := data_size/8192;
				return next;
			END LOOP;
		END IF;
		END LOOP;
	END;
$$;

alter function pg_get_delta_info(text, text, out text, out bigint, out bigint, out bigint) owner to omm;

