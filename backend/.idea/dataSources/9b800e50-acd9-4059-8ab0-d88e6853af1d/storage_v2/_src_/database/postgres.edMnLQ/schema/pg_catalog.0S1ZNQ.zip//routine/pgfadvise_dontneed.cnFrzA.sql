create function pgfadvise_dontneed(relname regclass, OUT relpath text, OUT os_page_size bigint, OUT rel_os_pages bigint, OUT os_pages_free bigint) returns SETOF record
    cost 1
    rows 1
    language sql
as
$$
SELECT pg_catalog.pgfadvise($1, 'main', 20)
$$;

comment on function pgfadvise_dontneed(regclass, out text, out bigint, out bigint, out bigint) is 'equal';

alter function pgfadvise_dontneed(regclass, out text, out bigint, out bigint, out bigint) owner to omm;

