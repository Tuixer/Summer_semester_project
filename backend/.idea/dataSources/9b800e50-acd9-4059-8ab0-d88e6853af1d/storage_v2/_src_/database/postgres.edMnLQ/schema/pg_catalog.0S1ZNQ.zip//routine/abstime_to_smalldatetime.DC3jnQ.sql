create function abstime_to_smalldatetime(abstime) returns smalldatetime
    immutable
    strict
    language sql
as
$$
select pg_catalog.smalldatetime_in(pg_catalog.timestamp_out($1), 0::Oid, -1)
$$;

alter function abstime_to_smalldatetime(abstime) owner to omm;

