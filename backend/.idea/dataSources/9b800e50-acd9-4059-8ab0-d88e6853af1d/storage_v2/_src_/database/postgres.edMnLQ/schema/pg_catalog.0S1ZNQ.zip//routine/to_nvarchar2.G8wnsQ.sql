create function to_nvarchar2(numeric) returns nvarchar2
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.numeric_out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(numeric) owner to omm;

